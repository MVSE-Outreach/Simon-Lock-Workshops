import pygame, math, random, time, os
from threading import Thread

class Bat(Thread):
    
    speed = 0.1
    energy = 10.0
    score = 0

    def __init__(self, world):
        Thread.__init__(self)
        # If the module name only has one element, just use that (probs SerialBat)
        if len(self.__module__.split(".")) == 1: self.name = self.__module__
        # If the module name has more than one element, use the penultimate part
        else: self.name = self.__module__.split(".")[1]
        self.x = random.uniform(0.0, world.canvas.get_width())
        self.y = random.uniform(0.0, world.canvas.get_height())
        self.wingImage = None
        self.bodyImage = None
        self.direction = random.uniform(-180, 180)
        self.flapCounter = random.uniform(0, 10)
        self.world = world
        self.start()
        
    def setWingAppearance(self, wingDescriptor):
        # Add 7 to any size passed in by user - to stop bat being too small !
        scaling = (int(wingDescriptor[:4],2) + 7.0) / 22.0   # 22 is 1111 + 7
        self.wingImage = loadAndScaleImage("Wings", wingDescriptor[4:] + ".png", scaling)
        
    def setBodyAppearance(self, bodyDescriptor):
        # Add 7 to any size passed in by user - to stop bat being too small !
        scaling = (int(bodyDescriptor[:4],2) + 7.0) / 22.0   # 22 is 1111 + 7
        self.bodyImage = loadAndScaleImage("Bodies", bodyDescriptor[4:] + ".png", scaling)
        
    def getName(self):
        return self.name
    
    def setName(self, newName):
        self.name = newName

    def setColour(self, colour):
        self.wingImage.fill(colour, special_flags=pygame.BLEND_MULT)
        self.bodyImage.fill(colour, special_flags=pygame.BLEND_MULT)

    def ping(self):
        return self.world.ping(self)

    def turnLeft(self):
        # Turn left by one degree
        self.direction -= 1.0
        if self.direction < -180: self.direction += 360
        # Sleep a bit to prevent bat turning too quickly !
        time.sleep(0.02)
        
    def turnRight(self):
        # Turn right by one degree
        self.direction += 1.0
        if self.direction > 180: self.direction -= 360
        # Sleep a bit to prevent bat turning too quickly !
        time.sleep(0.02)

    def eat(self, insectSize):
        self.score += insectSize
        self.energy += insectSize
        
    def setSpeed(self, speed):
        self.speed = speed
        # Don't allow speed to be set above 1.0
        if self.speed > 1.0: self.speed = 1.0
        # Don't allow speed to be set below 0.1
        if self.speed < 0.1: self.speed = 0.1
        # If we have run out of energy, set speed to crawl
        if self.energy <= 0: self.speed = 0.1
        
    def moveYourself(self, canvas):
        # Use up energy proportional to speed
        self.energy -= self.speed/10.0
        # If there is no energy left, go at crawling speed
        if self.energy <= 0:
            self.speed = 0.1
            self.energy = 0
        self.x += (self.speed*20.0) * math.sin(math.radians(self.direction))
        self.y -= (self.speed*20.0) * math.cos(math.radians(self.direction))
        if(self.x > canvas.get_width()): self.x = 0.0
        if(self.x < 0): self.x = canvas.get_width()
        if(self.y > canvas.get_height()): self.y = 0.0
        if(self.y < 0): self.y = canvas.get_height()
        
    def drawYourself(self, canvas):
        if (self.wingImage != None) and  (self.bodyImage != None):
            if(self.flapCounter != 0):
                drawImage(canvas, self.wingImage, self.x, self.y, -self.direction)
            else: time.sleep(0.03)
            drawImage(canvas, self.bodyImage, self.x, self.y, -self.direction)
            if self.world.showScores:
                text = self.world.font.render(str(self.score), False, (255, 255, 255))
                position = text.get_rect()
                position.center = (self.x, self.y)
                canvas.blit(text, position)
            self.flapCounter += (self.speed * 3.0)
            if self.flapCounter > 3.0: self.flapCounter = 0.0

def drawImage(canvas, image, x, y, rotation):
    rotatedImage = pygame.transform.rotate(image, rotation)
    position = rotatedImage.get_rect()
    position.center = (x, y)
    canvas.blit(rotatedImage, position)

def loadAndScaleImage(folder, imageName, scaling):
    wholeFilename = "Images" + os.sep + folder + os.sep + imageName
    image = pygame.image.load(wholeFilename).convert_alpha()
    scaledWidth = int(float(image.get_width()) * scaling)
    scaledHeight = int(float(image.get_height()) * scaling)
    image = pygame.transform.smoothscale(image,(scaledWidth, scaledHeight))
    return image
        
