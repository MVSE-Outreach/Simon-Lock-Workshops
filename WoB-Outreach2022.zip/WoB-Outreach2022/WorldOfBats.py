import pygame, random, sys, importlib, os, time
import serial.tools.list_ports
from pygame.locals import *
from Insect import Insect
from SerialBat import SerialBat
from math import *

class WorldOfBats():

    bats = []
    insects = []
    showScores = False
    playing = True

    def __init__(self):
        pygame.init()
        self.font = pygame.font.SysFont("Arial", 26)
        self.canvas = pygame.display.set_mode((1000,640),DOUBLEBUF)
        self.canvas.set_alpha(False)
        self.background = pygame.image.load("background.jpg").convert()
        screenDimensions = (self.canvas.get_width(), self.canvas.get_height())
        self.background = pygame.transform.scale(self.background, screenDimensions)
        batNames = getBatNamesFromCave()
        generateBatCaveManifests(batNames)
        for name in batNames:
            module = importlib.import_module("BatCave." + name)
            self.bats.append(getattr(module, "MyBat")(self))
        for i in range(1,20): self.createNewInsect()

    def createNewInsect(self):
        size = random.randint(2,4)
        self.insects.append(Insect(self.canvas,(255,255,255),size))

    def updatePositions(self):
        for bat in self.bats:
            bat.moveYourself(self.canvas)
            # Don't do collision detection (to speed things up)
            # self.performCollisionDetection(bat)
        for insect in self.insects:
            # Every now and then move the insect
            if(everyNowAndThen()): insect.moveYourself(self.canvas)

    def draw(self):
        self.canvas.blit(self.background,(0,0))
        for insect in self.insects: insect.drawYourself(self.canvas)
        for bat in self.bats: bat.drawYourself(self.canvas)
        pygame.display.flip()

    def performCollisionDetection(self, bat):
        for other in self.bats:
            if(bat != other):
                if(diff(bat.x, other.x) < 20) and  (diff(bat.y, other.y) < 20):
                    bat.x += random.randint(-5,5)
                    bat.y += random.randint(-5,5)

    def performEatDetection(self):
        for bat in self.bats:
            for insect in self.insects:
                if (diff(bat.x, insect.x) < 10) and (diff(bat.y, insect.y) < 10):
                    self.insects.remove(insect)
                    bat.eat(insect.size)
                    self.createNewInsect()

    def ping(self, bat):
        angle = -1
        closestDistance = 0
        closestSize = 0
        if self.playing:
            for insect in self.insects:
                angle = - degrees(atan2(bat.x-insect.x, bat.y-insect.y))
                if(degreeDifference(angle, bat.direction) < 7):
                    x_dist = insect.x-bat.x;
                    y_dist = insect.y-bat.y;
                    rawDist = sqrt((x_dist * x_dist) + (y_dist * y_dist))
                    # Convert float distance into an int 0->127 (serial comms can't handle > 128)
                    distance = int(round(127 * rawDist/self.canvas.get_width()))
                    if(closestDistance == 0):
                        closestDistance = distance
                        closestSize = insect.size
                    if(distance < closestDistance):
                        closestDistance = distance
                        closestSize = insect.size
        return {"distance": closestDistance, "size": closestSize}

def everyNowAndThen():
    return random.randint(0,10) > 6

def diff(a,b):
    if(a < b): return b-a
    else: return a-b

def degreeDifference(a, b):
        distance = abs(a-b)
        if(distance > 180): distance = 360 - distance
        return distance

def processEvents():
    events = pygame.event.get()
    for event in events:
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_q: world.playing = False
            if event.key == pygame.K_TAB: world.showScores = not world.showScores
            if event.key == pygame.K_s:
                newSerialPorts = getNewSerialPortNames(dealtWithSerialPorts)
                if(len(newSerialPorts) != 0): connectNewSerialDevices(newSerialPorts)

def getBatNamesFromCave():
    batNames = []
    fileNames = os.listdir("BatCave")
    for name in fileNames:
        if os.path.isdir("BatCave" + os.sep + name) and (name.find(".") != 0):
            if "__pycache__" not in name: batNames.append(name)
    return batNames

def generateBatCaveManifests(batNames):
    caveInitFile = open("BatCave" + os.sep + "__init__.py",'w')
    for name in batNames:
        batInitFile = open("BatCave" + os.sep + name + os.sep + "__init__.py",'w')
        batInitFile.write("from BatCave." + name + ".MyBat import MyBat\n")
        batInitFile.close()
        caveInitFile.write("from BatCave." + name + ".MyBat import MyBat\n")
    caveInitFile.close()

def getNewSerialPortNames(oldNames):
    newNames = []
    ports = serial.tools.list_ports.comports()
    for port in ports:
        name = port.device
        chip = port.description
        if ("CH340" in chip) and (name not in oldNames): newNames.append(name)
    return newNames

def connectNewSerialDevices(newNames):
    for portName in newNames:
        print("Connecting " + portName)
        world.bats.append(SerialBat(portName, world))
        dealtWithSerialPorts.append(portName)

world = WorldOfBats()
clock = pygame.time.Clock()
frameRate = 15
# Disregard any devices already connected
dealtWithSerialPorts = []

while world.playing:
    processEvents()
    world.updatePositions()
    world.performEatDetection()
    world.draw()
    clock.tick(frameRate)

pygame.quit()
for bat in world.bats: print(bat.getName() + ": " + str(bat.score))
