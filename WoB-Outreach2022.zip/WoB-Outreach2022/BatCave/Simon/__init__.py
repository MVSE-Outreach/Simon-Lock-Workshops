from BatCave.Simon.MyBat import MyBat
