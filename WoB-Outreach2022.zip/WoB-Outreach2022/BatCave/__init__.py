from BatCave.Simon.MyBat import MyBat
from BatCave.YourBatsName.MyBat import MyBat
