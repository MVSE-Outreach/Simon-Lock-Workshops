import random, pygame

class Insect:
    
    def __init__(self, canvas, colour, size):
        self.x = random.uniform(0, canvas.get_width())
        self.y = random.uniform(0, canvas.get_height())
        self.colour = colour
        self.size = size
    
    def moveYourself(self, canvas):
        self.x += random.uniform(-self.size,self.size)
        self.y += random.uniform(-self.size,self.size)
        if(self.x > canvas.get_width()): self.x = 0.0
        if(self.x < 0): self.x = canvas.get_width()
        if(self.y > canvas.get_height()): self.y = 0.0
        if(self.y < 0): self.y = canvas.get_height()
        
    def drawYourself(self, canvas):
        leftWing = (int(self.x - (self.size-2)),int(self.y))
        rightWing = (int(self.x + (self.size-2)),int(self.y))
        pygame.draw.circle(canvas, self.colour, leftWing, int(self.size), 1)
        pygame.draw.circle(canvas, self.colour, rightWing, int(self.size), 1)        